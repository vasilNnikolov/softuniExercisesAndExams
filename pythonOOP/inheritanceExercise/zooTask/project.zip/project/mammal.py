from project.animal import Animal

class Mammal(Animal):
    pass

a = Animal("a")
m = Mammal("m")

print(a.name)